﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Markup;
using System.IO;

namespace Adorners
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            StreamReader sr = new StreamReader(Application.GetResourceStream(new Uri("/Adorners;component/Techy.xaml", UriKind.Relative)).Stream);
            object c = XamlReader.Load(sr.ReadToEnd());
            Viewbox vb = new Viewbox() { Content = c, Width = 200, Height = 220, Stretch = Stretch.Fill, RenderTransformOrigin = new Point(0.5,0.5) };
            vb.RenderTransform = new MatrixTransform() { Matrix = new Matrix(1,0,0,1,-20,-200) };
            LayoutRoot.Children.Add(vb);
        }
        protected override void OnKeyDown(KeyEventArgs e)
        {
            FocusManager.GetFocusedElement();
            base.OnKeyDown(e);
        }
        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            foreach (UIElement l in VisualTreeHelper.FindElementsInHostCoordinates(e.GetPosition(null), this))
            {
                if (l is Rectangle || l is Image || l is Viewbox )
                {
                    adorn.AdornedElement = l as FrameworkElement;
                    adorn.adorned_MouseLeftButtonDown(l, e);
                    break;
                }
            }
            base.OnMouseLeftButtonDown(e);
        }

    }
}
