﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Media.Effects;

namespace Adorners
{
    public partial class Adorner : UserControl
    {
        FrameworkElement current;

        public Adorner()
        {
            InitializeComponent();

            Visibility = Visibility.Collapsed;
            RenderTransformOrigin = new Point(0.5, 0.5);

            RotateGrip.DragDelta += new System.Windows.Controls.Primitives.DragDeltaEventHandler(RotateGrip_DragDelta);
            RotateGrip.DragStarted += new System.Windows.Controls.Primitives.DragStartedEventHandler(RotateGrip_DragStarted);

            SizeGrip.DragDelta += new System.Windows.Controls.Primitives.DragDeltaEventHandler(SizeGrip_DragDelta);
        }

        void Subscribe()
        {
            current.MouseLeftButtonDown += adorned_MouseLeftButtonDown;
            current.MouseLeftButtonUp += adorned_MouseLeftButtonUp;
            current.MouseMove += adorned_MouseMove;
            current.MouseWheel += adorned_MouseWheel;
        }
        void UnSubscribe()
        {
            current.MouseLeftButtonDown -= adorned_MouseLeftButtonDown;
            current.MouseLeftButtonUp -= adorned_MouseLeftButtonUp;
            current.MouseMove -= adorned_MouseMove;
            current.MouseWheel -= adorned_MouseWheel;
        }

        public FrameworkElement AdornedElement
        {
            set
            {
                if (current == value)
                    return;

                if (current != null)
                {
                    UnSubscribe();
                    current.Effect = null;
                }

                if (value == null)
                {
                    Visibility = Visibility.Collapsed;

                    ClearValue(TransformProperty);
                    ClearValue(WidthProperty);
                    ClearValue(HeightProperty);

                    current = null;
                }
                else
                {

                    current = value;

                    RenderTransformOrigin = current.RenderTransformOrigin;
                    if (current.RenderTransform == null)
                        current.RenderTransform = new MatrixTransform();

                    SetBinding(TransformProperty, new System.Windows.Data.Binding("RenderTransform") { Source = current });
                    SetBinding(WidthProperty, new System.Windows.Data.Binding("Width") { Source = current });
                    SetBinding(HeightProperty, new System.Windows.Data.Binding("Height") { Source = current });

                    Subscribe();

                    Visibility = Visibility.Visible;

                    current.Effect = new DropShadowEffect() { Opacity = 0.5, BlurRadius = 10, ShadowDepth = 0 };
                }
            }
            get { return current; }
        }

        bool isDragging = false;
        Point dragAnchor;
        void adorned_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            Point p = e.GetPosition(sender as UIElement);
            p.X /= current.Width;
            p.Y /= current.Height;

            double w = Width * 0.0005 * e.Delta;
            double h = Height * 0.0005 * e.Delta;

            current.Width += w;
            current.Height += h;

            Point tansf = new Point((RenderTransformOrigin.X - p.X) * w, (RenderTransformOrigin.Y - p.Y) * h);
            tansf = RenderTransform.Transform(tansf);

            Matrix mx = (current.RenderTransform as MatrixTransform).Matrix;
            mx.OffsetX = tansf.X;
            mx.OffsetY = tansf.Y;
            current.RenderTransform = new MatrixTransform() { Matrix = mx };
        }

        void adorned_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDragging)
            {
                Point pt = e.GetPosition(null);

                Matrix mx = (current.RenderTransform as MatrixTransform).Matrix;
                mx.OffsetX += pt.X - dragAnchor.X;
                mx.OffsetY += pt.Y - dragAnchor.Y;
                current.RenderTransform = new MatrixTransform() { Matrix = mx };
                dragAnchor = pt;
            }
        }

        void adorned_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (isDragging)
            {
                (sender as FrameworkElement).ReleaseMouseCapture();
            }
            isDragging = false;
        }

        public void adorned_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if ((sender as FrameworkElement).CaptureMouse())
            {
                isDragging = true;
                dragAnchor = e.GetPosition(null);
            }
        }

        void SizeGrip_DragDelta(object sender, System.Windows.Controls.Primitives.DragDeltaEventArgs e)
        {
            Point p = new Point(e.HorizontalChange, e.VerticalChange);

            double w = p.X * (1 / (1 - RenderTransformOrigin.X));
            double h = p.Y * (1 / (1 - RenderTransformOrigin.Y));

            if (current.Width + w < 10)
                w = 0;
            if (current.Height + h < 10)
                h = 0;

            current.Width += w;
            current.Height += h;
        }

        Point start;
        Point cpt;
        Matrix mx;
        void RotateGrip_DragStarted(object sender, System.Windows.Controls.Primitives.DragStartedEventArgs e)
        {
            start = new Point (e.HorizontalOffset, e.VerticalOffset);
            cpt = start;
            mx = (current.RenderTransform as MatrixTransform).Matrix;
        }

        void RotateGrip_DragDelta(object sender, System.Windows.Controls.Primitives.DragDeltaEventArgs e)
        {
            cpt.X += e.HorizontalChange;
            cpt.Y += e.VerticalChange;

            double a = Math.Atan2(cpt.Y - Height * RenderTransformOrigin.Y, cpt.X - Width * RenderTransformOrigin.X)
                - Math.Atan2(start.Y - Height * RenderTransformOrigin.Y, start.X - Width * RenderTransformOrigin.X);

            Matrix rotate = new Matrix(Math.Cos(a), Math.Sin(a), -Math.Sin(a), Math.Cos(a), 0, 0);
            Matrix mnew = G.Mul(mx, rotate);

            current.RenderTransform = new MatrixTransform() { Matrix = mnew };
        }

        #region Transform (DependencyProperty)

        /// <summary>
        /// A description of the property.
        /// </summary>
        public Transform Transform
        {
            get { return (Transform)GetValue(TransformProperty); }
            set { SetValue(TransformProperty, value); }
        }
        public static readonly DependencyProperty TransformProperty =
            DependencyProperty.Register("Transform", typeof(Transform), typeof(Adorner),
            new PropertyMetadata(new PropertyChangedCallback(OnTransformChanged)));

        private static void OnTransformChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((Adorner)d).OnTransformChanged(e);
        }

        protected virtual void OnTransformChanged(DependencyPropertyChangedEventArgs e)
        {
            Transform r = e.NewValue as Transform;
            RenderTransform = r;
        }

        #endregion

    }


    public class G
    {
        /*
         * Dot product of two vectors
        */
        static public double Dot(Point v1, Point v2)
        {
            return v1.X * v2.X + v1.Y * v2.Y;
        }

        /*
         * Return angle in radians of two vectors
         */
        static public double Angle(Point v1, Point v2)
        {
            return Math.Acos(Dot(v1, v2) / (Length(v1) * Length(v2)));
        }
        static public double Angle(Line l1, Line l2)
        {
            Point v1 = new Point(l1.X2 - l1.X1, l1.Y2 - l1.Y1);
            Point v2 = new Point(l2.X2 - l2.X1, l2.Y2 - l2.Y1);
            return Angle(v1, v2);
        }
        static public double Length(Point v)
        {
            return Math.Sqrt(v.X * v.X + v.Y * v.Y);
        }

        /*
         * Matrix composition
         */
        static public Matrix Mul(Matrix m1, Matrix m2)
        {
            Matrix m = new Matrix();
            m.M11 = m1.M11 * m2.M11 + m1.M12 * m2.M21;
            m.M12 = m1.M11 * m2.M12 + m1.M12 * m2.M22;
            m.M21 = m1.M21 * m2.M11 + m1.M22 * m2.M21;
            m.M22 = m1.M21 * m2.M12 + m1.M22 * m2.M22;
            m.OffsetX = m1.OffsetX + m2.OffsetX;
            m.OffsetY = m1.OffsetY + m2.OffsetY;
            return m;
        }
    }
}
